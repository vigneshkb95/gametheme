$('.menu').on('click', function() {

        var submenu = $(this).children('.sub-menu');

        if(submenu.hasClass('menu-open')) {
            submenu.removeClass('menu-open');
          $(this).removeClass('menu-active');
        } else {
            $('.sub-menu').removeClass('menu-open');
            $('li').removeClass('menu-active');
            submenu.addClass('menu-open');
            $(this).addClass('menu-active');
        }

    });
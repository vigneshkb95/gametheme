<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">    
<?php wp_head(); ?>



</head>

<body ><!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">    
<?php wp_head(); ?>



</head>

<body <?php body_class(); ?>>

<section id="header" class="">
   <div class="container">
          <div class="row"> 
               <div class="logo col-md-3 col-sm-3 col-xs-12"> 
                    <?php
                    $custom_logo_id = get_theme_mod( 'custom_logo' );
                    $logo = wp_get_attachment_image_src( $custom_logo_id , 'full' );
                    if ( has_custom_logo() ) {
                     echo '<a href="http://localhost/gametheme/"><img src="' .esc_url( $logo[0]). '" alt="' . get_bloginfo( 'name' ) . '"></a>';
                     } else {
                    echo '<h1>'. get_bloginfo( 'name' ) .'</h1>';
                    } 
                     ?>
                </div>
         
                <div class="header_right col-md-9 col-sm-9 col-xs-12">        
                  <div class="header_location">
                    <a href="www.google.com"><h3>Location</h3></a>
                    <p>22 Mayne Street TIARO QLD 4650</p>
                 </div>
           
                   <div class="header_hours">
                      <h3>Trading hours</h3>
                       <ul>
                       <li>Mon - Fri : 8.00am - 5.30pm</li>
                       <li>Sat : 8.00am - 12.30pm</li>
                      </ul>
                   </div>
           
                     <div class="header_call">
                          <h3>Call Our Friendly Staff</h3>
                       <ul>
                           <li><a href="#">07 4129 2107</a></li>
                          <li><a href="#">sales@bhrural.com.au</a></li>
                      </ul>
                     </div>
           
                     <div class="header_patners">
                        <div class="header_pat_logo">
                           <img src="<?php echo get_template_directory_uri() . '/images/STIHL_logo.jpg' ?>" alt="STIHL_logo" />
                           <img src="<?php echo get_template_directory_uri() . '/images/Nutrien_logo.jpg' ?>" alt="Nutrien_logo" />                  
                       </div>
                       <div class="header_follow">
                          <h5>Follow us on</h5>               
                           <img src="<?php echo get_template_directory_uri() . '/images/facebook_header.png' ?>" alt="facebook_header"/>
                       </div>
             </div>
         </div>
         </div>
            </div>
          </div>  
           <div>
           </div>
           </div>
           
       
</section>
    
    

    
    

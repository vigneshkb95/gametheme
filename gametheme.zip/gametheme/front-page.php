<?php
/**
* Template Name: Homepage
 */

get_header(); ?> 

<?php echo the_content(); ?>





      













<?php get_footer(); ?>
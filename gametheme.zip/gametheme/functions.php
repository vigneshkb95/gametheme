<?php 
add_theme_support('menus');
add_theme_support('post-thumbnails');
add_theme_support( 'title-tag' );
add_theme_support( 'custom-logo' );




function namespace_theme_stylesheets() {
    wp_register_style( 'theme_style1',  get_template_directory_uri() .'/css/style.css', array(), null, 'all' );
    //wp_register_style( 'theme_style3',  get_template_directory_uri() .'/css/font-awesome.min.css', array(), null, 'all' );
	wp_register_style( 'theme_style4',  get_template_directory_uri() .'/css/font-awesome.css', array(), null, 'all' );
    wp_enqueue_style( 'theme_style1' );
    wp_enqueue_style( 'theme_style2' );
	wp_enqueue_style( 'theme_style3' );
	wp_enqueue_style( 'theme_style4' );
}
add_action( 'wp_enqueue_scripts', 'namespace_theme_stylesheets' );



function my_scripts() {
    wp_enqueue_style('bootstrap3', 'https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css');
    wp_enqueue_script( 'bootjs','https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js', array( 'jquery' ),'',true );
}
add_action( 'wp_enqueue_scripts', 'my_scripts' );



function add_my_script() {
  wp_enqueue_script(
    'bootstrap',
    get_template_directory_uri() . '/js/bootstrap.min.js',
    array('jquery')
  );
  wp_enqueue_script(
    'jquery.easing',
    get_template_directory_uri() . '/js/jquery.easing.min.js',
    array('jquery')
  );
 
}   
add_action( 'wp_enqueue_scripts', 'add_my_script' );




function loadjs()
{
  wp_register_script('customjs', get_template_directory_uri() . '/js/custom.js', '', 1, true);
  wp_enqueue_script('customjs');
}
add_action('wp_enqueue_scripts', 'loadjs');




add_filter( 'nav_menu_link_attributes', function($atts) {
    $atts['class'] = "js-scroll-trigger";
    return $atts;
}, 100, 1 );

if( function_exists('acf_add_options_page') ) {
acf_add_options_page(array(

        'page_title' 	=> 'Theme General Settings',
        'menu_title'	=> 'Theme Settings',
        'menu_slug' 	=> 'theme-general-settings',
        'capability'	=> 'edit_posts',
        'redirect'		=> false

));

acf_add_options_sub_page(array(

        'page_title' 	=> 'Theme Header Settings',
        'menu_title'	=> 'Header',
        'parent_slug'	=> 'theme-general-settings',

));


acf_add_options_sub_page(array(

        'page_title' 	=> 'Theme Footer Settings',
        'menu_title'	=> 'Footer',
        'parent_slug'	=> 'theme-general-settings',

));
	



   }            
      
      

               
     






